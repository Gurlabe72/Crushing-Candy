var store3 = [{
    'date': '2015-01-06',
    'inventory sold': {
        'Dark Chocolate Crunchies': {
            'cost': 4.29,
            'quantity': 1
        },
        'Mint Wafers': {
            'cost': 1.09,
            'quantity': 0
        },
        'Peppermint Poppers': {
            'cost': 2.38,
            'quantity': 3
        },
        'Peanut Butter Buttered Peanuts': {
            'cost': 1.79,
            'quantity': 2
        },
        'Berry Bites': {
            'cost': 7.89,
            'quantity': 0
        },
        'Caramel Twists': {
            'cost': .50,
            'quantity': 0
        },
        'Banana Bunches': {
            'cost': 4.53,
            'quantity': 1
        }
    }
}, {
    'date': '2015-01-07',
    'inventory sold': {
        'Dark Chocolate Crunchies': {
            'cost': 4.29,
            'quantity': 0
        },
        'Mint Wafers': {
            'cost': 1.09,
            'quantity': 2
        },
        'Peppermint Poppers': {
            'cost': 2.38,
            'quantity': 1
        },
        'Peanut Butter Buttered Peanuts': {
            'cost': 1.79,
            'quantity': 0
        },
        'Berry Bites': {
            'cost': 7.89,
            'quantity': 3
        },
        'Caramel Twists': {
            'cost': .50,
            'quantity': 7
        },
        'Banana Bunches': {
            'cost': 4.53,
            'quantity': 1
        }
    }
}, {
    'date': '2015-01-08',
    'inventory sold': {
        'Dark Chocolate Crunchies': {
            'cost': 4.29,
            'quantity': 1
        },
        'Mint Wafers': {
            'cost': 1.09,
            'quantity': 1
        },
        'Peppermint Poppers': {
            'cost': 2.38,
            'quantity': 0
        },
        'Peanut Butter Buttered Peanuts': {
            'cost': 1.79,
            'quantity': 0
        },
        'Berry Bites': {
            'cost': 7.89,
            'quantity': 0
        },
        'Caramel Twists': {
            'cost': .50,
            'quantity': 2
        },
        'Banana Bunches': {
            'cost': 4.53,
            'quantity': 0
        }
    }
}, {
    'date': '2015-01-09',
    'inventory sold': {
        'Dark Chocolate Crunchies': {
            'cost': 4.29,
            'quantity': 0
        },
        'Mint Wafers': {
            'cost': 1.09,
            'quantity': 3
        },
        'Peppermint Poppers': {
            'cost': 2.38,
            'quantity': 2
        },
        'Peanut Butter Buttered Peanuts': {
            'cost': 1.79,
            'quantity': 1
        },
        'Berry Bites': {
            'cost': 7.89,
            'quantity': 0
        },
        'Caramel Twists': {
            'cost': .50,
            'quantity': 0
        },
        'Banana Bunches': {
            'cost': 4.53,
            'quantity': 1
        }
    }
}, {
    'date': '2015-01-10',
    'inventory sold': {
        'Dark Chocolate Crunchies': {
            'cost': 4.29,
            'quantity': 2
        },
        'Mint Wafers': {
            'cost': 1.09,
            'quantity': 1
        },
        'Peppermint Poppers': {
            'cost': 2.38,
            'quantity': 0
        },
        'Peanut Butter Buttered Peanuts': {
            'cost': 1.79,
            'quantity': 2
        },
        'Berry Bites': {
            'cost': 7.89,
            'quantity': 5
        },
        'Caramel Twists': {
            'cost': .50,
            'quantity': 7
        },
        'Banana Bunches': {
            'cost': 4.53,
            'quantity': 2
        }
    }
}];

module.exports = store3;